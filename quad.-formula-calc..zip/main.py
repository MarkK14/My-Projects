print("in Standard form (  (a)x^2 + (b)x + (c) = 0  )")
a=input("what is your value for a? ")
b=input("value of b? ")
c=input("value of c? ")
a=float(a)
b=float(b)
c=float(c)
discr=((b**2)-4*a*c)
rootOne=(-1*b+(discr)**0.5)/(2*a)
rootTwo=(-1*b-(discr)**0.5)/(2*a)

if discr<0:
    print ("There are no roots to the equation ("+str(a)+")x^2 + ("+str(b)+")x + ("+str(c)+")")
else:
    rootOne=round(rootOne,3)
    rootTwo=round(rootTwo,3)
    print("The roots of the equation ("+str(a)+")x^2 + ("+str(b)+")x + ("+str(c)+")")
    print("are "+str(rootOne)+" and "+str(rootTwo))
