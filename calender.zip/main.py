print ("\t\t      February")
print("Sun\tMon\tTue\tWed\tThu\tFri\tSat\n\n1\t2\t3\t4\t5\t6\t7\n\n8\t9\t10\t11\t12\t13\t14\n\n15\t16\t17\t18\t19\t20\t21\n\n22\t23\t24\t25\t26\t27\t28\n\n(29)\t\t\t\t\t\t")
