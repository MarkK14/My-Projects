print("I am the smartest program ever and I order u to give me two numbers")
n1=input("Input first number: ")
n2=input("Input second number: ")
n1=int(n1)
n2=int(n2)
if n1>n2:
    print (f"{n1} is the bigger of these to numbers")
elif n2>n1:
    print (f"{n2} is the bigger of these to numbers")
elif n1==n2:
    print("You feeble minded fool.  You have submitted the same number TWICE!")
