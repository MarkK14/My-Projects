courseOne=input("what was your Term mark in your Period 1 course? ")
courseTwo=input("what was your Term mark in your Period 2 course? ")
courseThree=input("what was your Term mark in your Period 3 course? ")
courseFour=input("and lastly, what was your Term mark in your Period 4 course? ")
courseOne=float(courseOne)
courseTwo=float(courseTwo)
courseThree=float(courseThree)
courseFour=float(courseFour)
average=(courseOne+courseTwo+courseThree+courseFour)/4
if average>=60:
    print(f"CONGRATULATIONS you passed! Your average is {average}% Great Job!" )
else:
    print(f"Unfortunately you FAILED your average is {average}% Atleast you tried your best, right?")
