num=input("pick a number any number ... ")
num=int(num)
x=num%2
if x==0:
    y="Even"
else:
    y="Odd"
print("your number is an "+y+" number")