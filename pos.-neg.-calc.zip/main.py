num=input("Hello stranger, I challenge you to give me any number positive or negative ")
num=float(num)
if num>0:
    print(f"I am so SMART the number {num} is positive")
elif num<0:
    print(f"I must be a GENIUS the number {num} is negative")
elif num==0:
    print("Ha Ha Ha Ha This is the number ZERO it is neither positive nor negative")