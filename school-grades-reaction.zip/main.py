mark=input("What mark did you get? ")
mark=int(mark)
if mark>=80:
    print("Congrats that is an A")
elif mark>=70:
    print("Ok that is a B")
elif mark>=60:
    print("Tuffff thats a C")
elif mark>=50:
    print("Yanharak eswed thats a D")
elif mark<50:
    print("kharabt betna ya ghabi, Ya FASHEL!")