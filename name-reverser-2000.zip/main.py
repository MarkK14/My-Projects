print("Welcome to the Name Reverser enter your name with the first letter Capitalised")
firstName=input("what is your first name ")
lastName=input("What is your last name ")
if firstName == "Mark" and lastName =="Khairallah":
    print("Kalos aki sharon emfo-ou O Mark Khairallah")
else:
    print("your name on legal documents is "+lastName+","+firstName)
